// 메인앱: src/types/ui5-shims.d.ts
declare module '@ui5/webcomponents-base/dist/config/Language.js' {
  export function setLanguage(language: string): Promise<void>;
}
