import axios from "axios";

type AnyCfg = any;

async function readRuntimeConfig(): Promise<AnyCfg | undefined> {
  // 1) legacy: window.config.get()
  try {
    const v = await (window as any)?.config?.get?.();
    if (v) return v;
  } catch {}

  // 2) legacy-compat: window.config.getConfig()
  try {
    const v = await (window as any)?.config?.getConfig?.();
    if (v) return v;
  } catch {}

  // 3) unified: window.electronAPI.config.get()
  try {
    const v = await (window as any)?.electronAPI?.config?.get?.();
    if (v) return v;
  } catch {}

  // 4) IPC fallback: electronAPI.invoke("config:get")
  try {
    const v = await (window as any)?.electronAPI?.invoke?.("config:get");
    if (v) return v;
  } catch {}

  // 5) nothing
  return undefined;
}

function pick<T = any>(o: any, paths: string[], def?: T): T | undefined {
  for (const p of paths) {
    const segs = p.split(".");
    let cur: any = o;
    let ok = true;
    for (const s of segs) {
      if (cur && s in cur) cur = cur[s];
      else { ok = false; break; }
    }
    if (ok && cur != null && String(cur).trim() !== "") return cur as T;
  }
  return def;
}

export async function getMesAxios() {
  let chosenHost = "";
  let chosenPort = 0;
  let apiKey: string | undefined;
  let source = "fallback";

  // 0) 런타임 컨피그 수집 (XML→preload)
  const cfg = await readRuntimeConfig();

  // 1) SERVICE 블록 우선
  if (cfg) {
    const svcHost = pick<string>(cfg, [
      "SERVICE.HOST", "Service.HOST", "service.host", "service.HOST", "SERVICE.host"
    ]);
    const svcPort = Number(pick<number>(cfg, [
      "SERVICE.PORT", "Service.PORT", "service.port", "service.PORT", "SERVICE.port"
    ], 0));
    const svcKey  = pick<string>(cfg, ["SERVICE.API_KEY", "service.api_key", "service.API_KEY"]);

    if (svcHost) { chosenHost = String(svcHost).trim(); source = "Config(SERVICE.HOST)"; }
    if (svcPort > 0) chosenPort = svcPort;
    if (svcKey) apiKey = String(svcKey);
  }

  // 2) localStorage override
  if (!chosenHost) {
    const h = (localStorage.getItem("MES_API_HOST") || "").trim();
    if (h) { chosenHost = h; source = "localStorage(MES_API_HOST)"; }
  }
  if (!chosenPort) {
    const p = Number(localStorage.getItem("MES_API_PORT") || "0");
    if (p > 0) chosenPort = p;
  }

  // 3) Vite env
  if (!chosenHost && typeof import.meta !== "undefined") {
    const h = (import.meta as any).env?.VITE_MES_API_HOST as string | undefined;
    if (h && h.trim()) { chosenHost = h.trim(); source = "env(VITE_MES_API_HOST)"; }
    const p = Number((import.meta as any).env?.VITE_MES_API_PORT || "0");
    if (!chosenPort && p > 0) chosenPort = p;
  }

  // 4) 현재 호스트
  if (!chosenHost && typeof location !== "undefined") {
    chosenHost = location.hostname || "127.0.0.1";
    source = "location.hostname";
  }

  // 5) 기본값
  if (!chosenHost) { chosenHost = "127.0.0.1"; source = "hard-default"; }
  if (!chosenPort) chosenPort = 4001;

  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (apiKey) headers["x-api-key"] = String(apiKey);

  const baseURL = `http://${chosenHost}:${chosenPort}`;
  console.log(`[MesAxios] baseURL=${baseURL} (source=${source})`, apiKey ? "[with x-api-key]" : "[no api key]");

  return axios.create({ baseURL, headers });
}
