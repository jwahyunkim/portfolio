//C:\Changshin\test\electron-app_final\src\renderer\time\usePlantClock.ts
import { useEffect, useRef, useState } from "react";

type Source = "plant" | "local" | null;

type GlobalClock = {
  baseServerMs: number | null;
  basePerf: number | null;
  displayTZ?: string | null;
  displaySource?: Source;
  ready?: boolean;
};

const getLocalTZ = () => Intl.DateTimeFormat().resolvedOptions().timeZone;

export function usePlantClock() {
  const [displayReady, setDisplayReady] = useState(false);
  const [displaySource, setDisplaySource] = useState<Source>(null);
  const [displayTZ, setDisplayTZ] = useState<string | null>(null);
  const [nowTime, setNowTime] = useState(new Date());

  const baseServerMsRef = useRef<number | null>(null);
  const basePerfRef = useRef<number | null>(null);

  const bootOnceRef = useRef(false);
  if (!bootOnceRef.current) {
    bootOnceRef.current = true;
    const gc: GlobalClock =
      (window as any).__GLOBAL_CLOCK__ ?? ((window as any).__GLOBAL_CLOCK__ = {
        baseServerMs: null,
        basePerf: null,
      });

    if (gc.baseServerMs == null || gc.basePerf == null) {
      gc.baseServerMs = Date.now();
      gc.basePerf = performance.now();
    }
  }

  useEffect(() => {
    const gc = (window as any).__GLOBAL_CLOCK__ as GlobalClock;
    baseServerMsRef.current = gc?.baseServerMs ?? Date.now();
    basePerfRef.current = gc?.basePerf ?? performance.now();
  }, []);

  useEffect(() => {
    const time = (window as any).time;
    const gc = (window as any).__GLOBAL_CLOCK__ as GlobalClock;

    const setLocal = () => {
      gc.displaySource = "local";
      gc.displayTZ = getLocalTZ();
      gc.ready = true;

      setDisplaySource("local");
      setDisplayTZ(gc.displayTZ!);
      setDisplayReady(true);
    };

    const applyCtx = (ctx: any) => {
      if (!ctx) return setLocal();

      const tz = ctx?.timeZone ?? ctx?.timezone ?? ctx?.tz ?? null;
      const src: Source = ctx?.source === "plant" ? "plant" : "local";

      if (src === "plant" && tz) {
        gc.displaySource = "plant";
        gc.displayTZ = tz;
        gc.ready = true;

        setDisplaySource("plant");
        setDisplayTZ(tz);
        setDisplayReady(true);
      } else {
        setLocal();
      }
    };

    if (!time) {
      setLocal();
      return;
    }

    // 최초 한 번만 컨텍스트 받아옴
    const off = time.onReadyOnce((ctx: any) => applyCtx(ctx));
    time.getContext().then(applyCtx).catch(setLocal);

    return () => {
      try {
        off?.();
      } catch {}
    };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      if (baseServerMsRef.current != null && basePerfRef.current != null) {
        const elapsed = performance.now() - basePerfRef.current;
        setNowTime(new Date(baseServerMsRef.current + elapsed));
      } else {
        setNowTime(new Date());
      }
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return { nowTime, displayReady, displaySource, displayTZ };
}

// ---- 포매터 ----
export const formatYYYYMMDDInTZ = (d: Date, tz: string) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);

export const formatTimeInTZ = (d: Date, tz: string) =>
  d.toLocaleTimeString("ko-KR", {
    timeZone: tz,
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
