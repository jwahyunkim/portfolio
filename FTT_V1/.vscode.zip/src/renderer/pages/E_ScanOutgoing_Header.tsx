// src/renderer/pages/E_ScanOutgoing_Header.tsx
// (아래 파일은 기존에서 동작상 바뀐 부분 없음: 서버만 zcf_work_date로 수정되면 그대로 동작)

import React, { useState, useEffect, useRef } from "react";
import type { CSSProperties } from "react";
import "./index.css";
import { FlexBox, Label, Button, DatePicker, Text } from "@ui5/webcomponents-react";
import { useNavigate } from "react-router-dom";

import "@ui5/webcomponents-react/dist/Assets.js";
import "@ui5/webcomponents-icons/dist/Assets.js";
import "@ui5/webcomponents-localization/dist/Assets.js";

import { initI18n, t } from "../utils/i18n";
import ClockDisplay from "../components/ClockDisplay";
import { getMesAxios } from "../utils/mesAxios";

import backIcon from "@renderer/resources/Back-Icon.png";
import loadingIcon from "@renderer/resources/loading1.png";
import E_ScanOutgoing_Detail_N from "./E_ScanOutgoing_Detail_N";

/* ================= 타입 ================= */
interface ComboItem { CODE: string; NAME: string; }
interface CardItem {
  material_code: string;
  goodsreceiptquantity: number | null;
  productionquantity: number | null;
  work_date?: string; // YYYY-MM-DD (서버에서 함께 반환)
}

/* ================= 유틸 ================= */
const upperOrNull = (v?: string) => {
  const s = (v ?? "").trim();
  return s ? s.toUpperCase() : null;
};
const ymd = (v: string) => (v || "").replace(/-/g, "");

/* =========================================================== */
export function E_ScanOutgoing_Header() {
  const navigate = useNavigate();

  const [plantList, setPlantList] = useState<ComboItem[]>([]);
  const [workcenterList, setWorkcenterList] = useState<ComboItem[]>([]);
  const [selectedPlant, setSelectedPlant] = useState("C200");
  const [selectedWorkcenter, setSelectedWorkcenter] = useState("OSOSP"); // 기본값
  const [lineCode, setLineCode] = useState("");
  const [machineCode, setMachineCode] = useState("");
  const [materialCode, setMaterialCode] = useState("");
  const [selectedDate, setSelectedDate] = useState("");

  const [autoRefresh, setAutoRefresh] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [cards, setCards] = useState<CardItem[]>([]);

  // 상세 모달
  const [detailOpen, setDetailOpen] = useState(false);
  const [detailData, setDetailData] = useState<any>(null);

  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => { initI18n().catch(() => {}); }, []);

  // 날짜 초기화
  useEffect(() => {
    const time = (window as any).time;
    const saved = localStorage.getItem("E_SCAN_DATE");
    const fallbackToday = () => new Date().toISOString().slice(0, 10);
    const applyWorkDate = (ctx: any) => {
      const wd = ctx?.workDate ?? ctx?.workday ?? ctx?.currentWorkday;
      const v = wd || saved || fallbackToday();
      setSelectedDate(v);
      localStorage.setItem("E_SCAN_DATE", v);
    };
    if (!time) { setSelectedDate(saved || fallbackToday()); return; }
    const off = time.onReadyOnce((ctx: any) => applyWorkDate(ctx));
    time.getContext().then(applyWorkDate).catch(() => setSelectedDate(saved || fallbackToday()));
    return () => { try { off?.(); } catch {} };
  }, []);

  // 콤보(PT/WC)
  useEffect(() => {
    (async () => {
      const mesAx = await getMesAxios();
      try {
        const pt = await mesAx.post("/db/pg/call/mes/sp_basic_info", { params: { p_type: "PT", p_plant_cd: null } });
        const ptRows = pt.data?.rows ?? pt.data ?? [];
        const plants: ComboItem[] = Array.isArray(ptRows)
          ? ptRows.map((r: any) => ({ CODE: r.code ?? r.CODE ?? "C200", NAME: r.name ?? r.NAME ?? (r.code ?? "C200") }))
          : [];
        setPlantList(plants.length ? plants : [{ CODE: "C200", NAME: "C200" }]);

        const wc = await mesAx.post("/db/pg/call/mes/sp_basic_info", { params: { p_type: "WC", p_plant_cd: selectedPlant } });
        const wcRows = wc.data?.rows ?? wc.data ?? [];
        const wcs: ComboItem[] = Array.isArray(wcRows)
          ? wcRows.map((r: any) => ({ CODE: r.code ?? r.CODE ?? "", NAME: r.name ?? r.NAME ?? (r.code ?? "") }))
          : [];
        setWorkcenterList(wcs.length ? wcs : [{ CODE: "OSOSP", NAME: "OSOSP" }]);

        const cur = (selectedWorkcenter || "").trim().toUpperCase();
        if (!wcs.find((x) => (x.CODE || "").trim().toUpperCase() === cur)) {
          setSelectedWorkcenter((wcs[0]?.CODE as string) || "OSOSP");
        }
      } catch (e) {
        console.error("PG(sp_basic_info) 콤보 로드 실패:", e);
        setPlantList((p) => (p.length ? p : [{ CODE: "C200", NAME: "C200" }]));
        setWorkcenterList((w) => (w.length ? w : [{ CODE: "OSOSP", NAME: "OSOSP" }]));
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedPlant]);

  // 조회
  const fetchCards = async () => {
    if (!selectedDate) return;

    const params = {
      p_plant:          upperOrNull(selectedPlant),
      p_material_code:  upperOrNull(materialCode),
      p_work_center:    upperOrNull(selectedWorkcenter),
      p_zcf_line_cd:    upperOrNull(lineCode),
      p_zcf_machine_cd: upperOrNull(machineCode),
      p_work_date:      selectedDate,  // yyyy-MM-dd
      p_only_done_zero: true,
    };

    setIsLoading(true);
    try {
      const mesAx = await getMesAxios();
      const res = await mesAx.post("/db/pg/call/mes/escan_header_q", { params });
      const data = res.data?.rows ?? res.data ?? [];
      const rows = Array.isArray(data) ? data : [];
      setCards(rows);
    } catch (err: any) {
      console.error("❌ escan_haeder_q 조회 실패(POSTGRES):", err?.response?.data || err);
      setCards([]);
    } finally {
      setIsLoading(false);
    }
  };

  // 자동 조회
  useEffect(() => {
    if (!autoRefresh || !selectedDate) return;
    fetchCards();
    intervalRef.current = setInterval(fetchCards, 60000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [selectedDate, autoRefresh]); // eslint-disable-line react-hooks/exhaustive-deps

  // 색상 판정
  const getCardColor = (c: CardItem) => {
    const todayYMD = ymd(new Date().toISOString().slice(0, 10));
    const wd = (c.work_date ?? "").trim();
    const isToday = wd ? ymd(wd) === todayYMD : false;

    const prod = Number(c.goodsreceiptquantity ?? 0);
    const plan = Number(c.productionquantity ?? 0);

    let status: "NONE" | "RUN" | "DONE" = "NONE";
    if (prod === 0) status = "NONE";
    else if (prod < plan) status = "RUN";
    else status = "DONE";

    if (status === "NONE") return isToday ? "#f9f9f9" : "#999999";
    if (status === "RUN") return "#FFA500";
    return "#00C853";
  };

  const cardStyle: CSSProperties = {
    width: "100%",
    borderRadius: 12,
    boxShadow: "0 1px 6px rgba(0,0,0,0.12)",
    padding: "0.8rem 0.7rem",
    textAlign: "center",
    fontWeight: 600,
    color: "#111",
    transform: "scale(0.95)",
  };

  const gridWrapStyle: CSSProperties = {
    display: "grid",
    gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
    columnGap: "0.7rem",
    rowGap: "0.4rem",
    alignItems: "start",
    justifyItems: "stretch",
    width: "100%",
    height: "calc(100vh - 260px)",
    overflowY: "auto",
    overflowX: "hidden",
    padding: "0.1rem 0.2rem",
  };

  const filterBox: CSSProperties = {
    background: "rgba(0,0,0,0.03)",
    padding: "1rem 1rem 0.5rem 1rem",
    borderBottom: "1px solid #ddd",
  };

  const legendWrap: CSSProperties = {
    display: "flex",
    alignItems: "center",
    gap: "1rem",
    margin: "0.75rem 0 0.5rem 0",
    fontSize: "1.05rem",
    fontWeight: 600,
  };

  const legendBox = (color: string) => ({
    display: "inline-block",
    width: 22,
    height: 22,
    backgroundColor: color,
    border: color === "#f9f9f9" ? "1px solid #ccc" : "1px solid #555",
    marginRight: 6,
    borderRadius: 4,
  });

  const inputStyle: CSSProperties = {
    fontSize: "1.05rem",
    padding: "0.45rem 0.6rem",
    borderRadius: 6,
    border: "1px solid #ccc",
  };

  const labelStyle: CSSProperties = {
    width: 80,
    fontSize: "1.05rem",
    display: "inline-block",
    fontWeight: 600,
  };

  const pillStyle: CSSProperties = {
    display: "inline-block",
    padding: "0.35rem 0.75rem",
    borderRadius: "999px",
    fontWeight: 700,
    background: "#3A3AFF",
    color: "#fff",
    marginLeft: "0.5rem"
  };

  const totalProd = cards.reduce((s, c) => s + Number(c.goodsreceiptquantity ?? 0), 0);
  const totalPlan = cards.reduce((s, c) => s + Number(c.productionquantity ?? 0), 0);

  const openDetail = (c: CardItem) => {
    const qty = Number(c.productionquantity ?? c.goodsreceiptquantity ?? 0);
    const tempOrder = `${selectedWorkcenter}-${c.material_code}`.slice(0, 12);
    const tempSfc   = `${c.material_code}-${ymd(selectedDate)}-TEMP`.slice(0, 128);

    setDetailData({
      WORK_DATE: selectedDate,
      WORK_CENTER: selectedWorkcenter,
      ORDER_NUMBER: tempOrder,
      MATERIAL_CODE: c.material_code,
      MATERIAL_DESCRIPTION: c.material_code,
      SIZE_CD: "-",
      SFC: tempSfc,
      QUANTITY: qty,
      PUTAWAYSTORAGELOCATION: ""
    });
    setDetailOpen(true);
  };

  return (
    <div>
      {/* 상단 타이틀 바 */}
      <FlexBox style={{ backgroundColor: "#0F005F", height: "5rem" }} justifyContent="SpaceBetween" alignItems="Center">
        <Label style={{ fontSize: "2rem", fontWeight: "bold", color: "white" }}>
          E-Scan Production (HEADER)
        </Label>
        <FlexBox direction="Row" alignItems="Start" gap="1rem">
          <img
            src={backIcon}
            alt="Back Icon"
            onClick={() => navigate("/")}
            style={{ width: "60px", height: "70px", padding: 0, marginTop: 6, cursor: "pointer" }}
          />
          <ClockDisplay />
        </FlexBox>
      </FlexBox>

      {/* 조회조건 + 범례 + 요약 */}
      <div style={filterBox}>
        <div style={{ display: "flex", alignItems: "center", gap: "1.25rem", flexWrap: "wrap" }}>
          <div>
            <Label style={labelStyle}>날짜</Label>
            <DatePicker
              value={selectedDate}
              valueFormat="yyyy-MM-dd"
              displayFormat="yyyy-MM-dd"
              style={{ ...inputStyle, width: 160 }}
              onChange={(e: any) => {
                const v = (e.detail.value as string) || "";
                setSelectedDate(v);
                localStorage.setItem("E_SCAN_DATE", v);
              }}
            />
          </div>

          <div>
            <Label style={labelStyle}>공장</Label>
            <select
              value={selectedPlant}
              style={{ ...inputStyle, width: 120 }}
              onChange={(e) => setSelectedPlant((e.target.value || "").trim().toUpperCase())}
            >
              {plantList.map((p) => {
                const v = (p.CODE || "").trim().toUpperCase();
                return <option key={p.CODE} value={v}>{v}</option>;
              })}
            </select>
          </div>

          <div>
            <Label style={labelStyle}>작업장</Label>
            <select
              value={selectedWorkcenter}
              style={{ ...inputStyle, width: 140 }}
              onChange={(e) => setSelectedWorkcenter((e.target.value || "").trim().toUpperCase())}
            >
              {workcenterList.map((w) => {
                const v = (w.CODE || "").trim().toUpperCase();
                return <option key={w.CODE} value={v}>{v}</option>;
              })}
            </select>
          </div>

          <div>
            <Label style={labelStyle}>라인</Label>
            <input
              value={lineCode}
              onChange={(e) => setLineCode((e.target.value || "").trim().toUpperCase())}
              placeholder="예: 2DUPC"
              style={{ ...inputStyle, width: 140 }}
            />
          </div>

          <div>
            <Label style={labelStyle}>장비</Label>
            <input
              value={machineCode}
              onChange={(e) => setMachineCode((e.target.value || "").trim().toUpperCase())}
              placeholder="장비코드"
              style={{ ...inputStyle, width: 140 }}
            />
          </div>

          <div>
            <Label style={labelStyle}>품번</Label>
            <input
              value={materialCode}
              onChange={(e) => setMaterialCode((e.target.value || "").trim().toUpperCase())}
              placeholder="Material Code"
              style={{ ...inputStyle, width: 180 }}
            />
          </div>
        </div>

        {/* Search + 자동조회 + 요약 */}
        <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", gap: "0.8rem", marginTop: "0.75rem" }}>
          <Button design="Emphasized" onClick={fetchCards} style={{ minWidth: 90 }}>Search</Button>

          <label style={{ display: "inline-flex", alignItems: "center", gap: "0.4rem", fontWeight: 700, fontSize: "1.05rem" }}>
            <input type="checkbox" checked={autoRefresh} onChange={(e) => setAutoRefresh(e.target.checked)} style={{ transform: "scale(1.2)" }} />
            <span>자동조회</span>
          </label>

          <span style={pillStyle}>생산수량 : {totalProd.toLocaleString()} Pairs</span>
          <span style={pillStyle}>계획수량 : {totalPlan.toLocaleString()} Pairs</span>
        </div>

        {/* 범례 */}
        <div style={legendWrap}>
          <div><span style={legendBox("#f9f9f9")}></span>오늘 미생산</div>
          <div><span style={legendBox("#999999")}></span>이전 미생산</div>
          <div><span style={legendBox("#FFA500")}></span>진행중</div>
          <div><span style={legendBox("#00C853")}></span>완료</div>
        </div>
      </div>

      {/* 카드 리스트 */}
      <div style={gridWrapStyle}>
        {cards.map((c, i) => (
          <div
            key={i}
            onClick={() => openDetail(c)}
            style={{
              ...cardStyle,
              backgroundColor: getCardColor(c),
              cursor: "pointer"
            }}
          >
            <Text style={{ fontWeight: "bold", fontSize: "1.35rem", color: "#0F005F" }}>
              {c.material_code}
            </Text>

            <div style={{ width: "60%", height: 1.5, backgroundColor: "#0F005F", margin: "0.5rem auto" }} />

            <div style={{ fontSize: "1.35rem", fontWeight: 800 }}>
              {Number(c.goodsreceiptquantity ?? 0).toLocaleString()}
              <span style={{ opacity: 0.6, padding: "0 0.3rem" }}>/</span>
              {Number(c.productionquantity ?? 0).toLocaleString()}
            </div>
          </div>
        ))}

        {cards.length === 0 && !isLoading && (
          <div style={{ margin: "2rem auto", fontSize: "1.5rem", color: "#666", gridColumn: "1 / -1", textAlign: "center" }}>
            {t("app.message.noData")}
          </div>
        )}
      </div>

      {isLoading && (
        <div
          style={{
            position: "fixed", inset: 0, backgroundColor: "rgba(255,255,255,0.85)",
            zIndex: 9999, display: "flex", justifyContent: "center", alignItems: "center"
          }}
        >
          <div
            style={{
              display: "flex", alignItems: "center", gap: 30, padding: 20,
              border: "2px solid gray", borderRadius: 16, backgroundColor: "#fff",
              boxShadow: "0 0 10px rgba(0,0,0,0.1)"
            }}
          >
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
              <div style={{ fontSize: 30, fontWeight: "bold", marginBottom: 10 }}>{t("ui.loading")}</div>
            </div>
            <div style={{ width: 300, height: 200 }}>
              <img src={loadingIcon} alt="Loading" style={{ width: "100%", height: "100%", objectFit: "contain" }} />
            </div>
          </div>
        </div>
      )}

      <E_ScanOutgoing_Detail_N
        open={detailOpen}
        onClose={() => setDetailOpen(false)}
        data={detailData}
        onConfirm={() => {}}
        plant_cd={selectedPlant}
        work_date={selectedDate}
      />
    </div>
  );
}

export default E_ScanOutgoing_Header;
