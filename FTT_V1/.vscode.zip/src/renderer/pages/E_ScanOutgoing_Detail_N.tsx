// src/renderer/pages/E_ScanOutgoing_Detail_N.tsx
import saveIcon from "@ui5/webcomponents-icons/dist/save.js";
import { useState, useEffect, useRef, useMemo } from "react";
import { Text, Button, Dialog, Toast } from "@ui5/webcomponents-react";
import okGreen from "@renderer/resources/E_Confirm_Ok.png";
import okOrange from "@renderer/resources/E_Confirm_Orange.png";
import okWhite from "@renderer/resources/E_Confirm_White.png";
import "./index2.css";
import { t } from "../utils/i18n";
import { getMesAxios } from "../utils/mesAxios";

/* ✅ 빠지면 백화면 나는 경우 많음: UI5 컴포넌트 등록용 Assets */
import "@ui5/webcomponents-react/dist/Assets.js";
import "@ui5/webcomponents-icons/dist/Assets.js";
import "@ui5/webcomponents-localization/dist/Assets.js";

/* ===================== 전역 디버그 유틸 ===================== */
const DEBUG = true;

function dlog(title: string, data?: any) {
  if (!DEBUG) return;
  try {
    console.groupCollapsed(`%c[DEBUG] ${title}`, "color:#08f;font-weight:bold");
    if (Array.isArray(data)) console.table(data);
    else if (data && typeof data === "object") console.log(data);
    else if (data !== undefined) console.log(String(data));
    console.groupEnd();
  } catch { /* noop */ }
}

// 컬럼 길이 기준(현재 dmpd_epcard_scan 스키마 기준)
const COL_MAX = {
  PLANT_CD: 4,
  BAR_KEY: 100,
  SFC_CD: 10,
  PCARD_SEQ: 10,
  WORK_CENTER: 50,
  ORDER_NUMBER: 10,
  DEVICE_ID: 20,
  USER_IP: 50,
  SCAN_TYPE: 1,
} as const;

// 안전 절단 유틸
const safe = {
  plant: (s: any) => String(s ?? "").slice(0, COL_MAX.PLANT_CD),
  bar:   (s: any) => String(s ?? "").slice(0, COL_MAX.BAR_KEY),
  sfc10: (s: any) => String(s ?? "").slice(0, COL_MAX.SFC_CD),
  wc:    (s: any) => String(s ?? "").slice(0, COL_MAX.WORK_CENTER),
  ord10: (s: any) => String(s ?? "").slice(0, COL_MAX.ORDER_NUMBER),
  dev:   (s: any) => String(s ?? "").slice(0, COL_MAX.DEVICE_ID),
  ip:    (s: any) => String(s ?? "").slice(0, COL_MAX.USER_IP),
};

// 저장 페이로드 길이/초과 표시
function dumpSavePayload(label: string, list: any[]) {
  if (!DEBUG) return;
  const rows = list.map((x, idx) => {
    const o: any = { idx, ...x };
    for (const k of Object.keys(COL_MAX) as (keyof typeof COL_MAX)[]) {
      const v = String(o[k] ?? "");
      o[`${k}_LEN`] = v.length;
      o[`${k}_OVER`] = v.length > (COL_MAX[k] ?? 9999);
    }
    return o;
  });
  dlog(`${label}: payload preview (first 8)`, rows.slice(0, 8));
  const offenders = rows
    .map((r) => ({
      idx: r.idx,
      over: Object.keys(COL_MAX).filter((k) => (r as any)[`${k}_OVER`]),
    }))
    .filter((x) => x.over.length);
  if (offenders.length) console.warn("[DEBUG] Length overflow detected:", offenders);
  else console.log("[DEBUG] No length overflow in payload.");
}

/* ===================== 레이아웃 상수 ===================== */
const MAIN_GAP_REM = 2.5;
const LEFT_INFO_W = 250;
const INFO_COL1_W = 120;
const FILTER_BTN_W = 145;
const FILTER_BTN_H = 90;

/* ===== 카드 표시 튜닝 ===== */
const CARD_SIDE_GAP = 10;
const CARD_ROW_GAP = 2;
const CARD_FONT_SIZE = 14;
const CARD_HEIGHT = 80;
const CARD_BADGE_WH = 60;

/* ===================== Props/Types ===================== */
export interface Props {
  open: boolean;
  onClose: () => void;
  data: any;
  onConfirm?: (saved?: any) => void;
  plant_cd: string;
  work_date: string; // 'YYYY-MM-DD'
}
type ConfirmYN = "N" | "T" | "P" | "Y" | " ";
interface CardItem {
  seq: number;
  qty: number;
  input_dt: string;
  prod_dt: string;
  confirm_YN: ConfirmYN;
  flag: string;
  sfc?: string;
  mappedSFC?: string;
  operation?: string;
  resource?: string;
  isSaving?: boolean;
  PCARD_QTY?: number;
  SCAN_TYPE?: string;
  UPLOAD_YN?: string;
}
type SavePayload = {
  PLANT_CD: string;
  BAR_KEY: string;
  SFC_CD: string;
  PCARD_SEQ: string;
  PCARD_QTY: number;
  WORK_CENTER: string;
  ORDER_NUMBER: string;
  DEVICE_ID: string;
  USER_IP: string;
  SCAN_TYPE: "T" | "P";
};
type Allocation = { order_number: string; zcf_seq: number; qty: number };
type FilterKey = "notStarted" | "inProgress" | "completed";

/* ========== 유틸: 길면 자동 폰트 축소 셀(왼쪽 표 값 칸 전용) ========== */
function FitTextCell({
  children, style, min = 10, max = 13,
}: { children: React.ReactNode; style?: React.CSSProperties; min?: number; max?: number; }) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const spanRef = useRef<HTMLSpanElement | null>(null);

  useEffect(() => {
    const wrap = wrapRef.current;
    const span = spanRef.current;
    if (!wrap || !span) return;
    let size = max;
    span.style.fontSize = `${size}px`;
    const fits = () => span.scrollWidth <= wrap.clientWidth;
    while (!fits() && size > min) {
      size -= 1;
      span.style.fontSize = `${size}px`;
    }
  }, [children, min, max]);

  return (
    <div
      ref={wrapRef}
      style={{
        width: "100%",
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
        boxSizing: "border-box",
        ...style,
      }}
    >
      <span ref={spanRef} style={{ display: "inline-block", verticalAlign: "top" }}>
        {children}
      </span>
    </div>
  );
}

/* ===================== 메인 컴포넌트 ===================== */
export default function E_ScanOutgoing_Detail_N({
  open, onClose, data, onConfirm, plant_cd, work_date,
}: Props) {
  const [cardData, setCardData] = useState<CardItem[]>([]);
  const originalRef = useRef<CardItem[]>([]);
  const [toastMessage, setToastMessage] = useState("");
  const [toastOpen, setToastOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [localIp, setLocalIp] = useState<string>("0.0.0.0");

  // === 필터 ===
  const [checked, setChecked] = useState<Record<FilterKey, boolean>>({
    notStarted: false, // N
    inProgress: false, // T
    completed: false, // P
  });

  // === (참고) 우측 높이 측정은 유지하지만 왼쪽은 height 자동 ===
  const rightRef = useRef<HTMLDivElement | null>(null);
  const [rightHeight, setRightHeight] = useState<number>(0);
  useEffect(() => {
    if (!rightRef.current) return;
    const el = rightRef.current;
    const update = () => setRightHeight(el.offsetHeight);
    update();

    if (typeof (window as any).ResizeObserver !== "undefined") {
      const ro = new (window as any).ResizeObserver(update);
      ro.observe(el);
      const onWin = () => update();
      window.addEventListener("resize", onWin);
      return () => { ro.disconnect(); window.removeEventListener("resize", onWin); };
    } else {
      const onWin = () => update();
      window.addEventListener("resize", onWin);
      return () => window.removeEventListener("resize", onWin);
    }
  }, [open]);

  const COLS = 2, ROWS = 4, pageSize = COLS * ROWS;

  const toast = (m: string) => {
    setToastMessage(m);
    setToastOpen(true);
    setTimeout(() => setToastOpen(false), 3000);
  };

  const colorOf = (it: CardItem) =>
    it.confirm_YN === "P" ? "limegreen" :
    it.confirm_YN === "T" ? "orange" :
    it.confirm_YN === "N" ? "white" : "#f5f5f5";

  const imgOf = (it: CardItem) => (it.confirm_YN === "P" ? okGreen : it.confirm_YN === "T" ? okOrange : okWhite);

  const toggle = (clicked: CardItem) => {
    setCardData((prev) =>
      prev.map((it) =>
        it.seq !== clicked.seq
          ? it
          : it.confirm_YN === "N"
          ? ({ ...it, confirm_YN: "T" as const })
          : it.confirm_YN === "T"
          ? ({ ...it, confirm_YN: "N" as const })
          : it
      )
    );
  };

  const modified = (orig: CardItem[], cur: CardItem[]) =>
    cur
      .map((c, i) => {
        const o = orig[i];
        const changed = c.confirm_YN !== o.confirm_YN;
        return {
          ...c,
          SCAN_TYPE: "P" as const,
          _changed: changed && (c.confirm_YN === "P" || c.confirm_YN === "T"),
        };
      })
      .filter((x: any) => x._changed)
      .map(({ _changed, ...rest }) => rest);

  /* ---------------- IP 조회 ---------------- */
  useEffect(() => {
    (async () => {
      try {
        const ax = await getMesAxios();
        const { data } = await ax.get("/api/get-ip", { headers: { Accept: "application/json" } });
        setLocalIp(String(data?.localIp ?? "0.0.0.0"));
      } catch {
        setLocalIp("0.0.0.0");
      }
    })();
  }, []);

  /* ---------------- 디테일 조회 ---------------- */
  useEffect(() => {
    if (!open || !data) return;

    (async () => {
      const ax = await getMesAxios();
      const qty = Number(data.QUANTITY || 0);
      const sfc = String(data.SFC || "").slice(0, 128);

      dlog("open detail with data", { plant_cd, work_date, data, qty, sfc });

      // 1) 기본 카드 구성 (즉시 렌더)
      const full = Math.floor(qty / 12);
      const rem = qty % 12;

      const base: CardItem[] = [];
      for (let i = 0; i < full; i++) {
        base.push({ seq: i + 1, qty: 12, input_dt: "", prod_dt: "", confirm_YN: "N", flag: "ACTIVE", sfc, mappedSFC: sfc });
      }
      if (rem > 0) {
        base.push({ seq: full + 1, qty: rem, input_dt: "", prod_dt: "", confirm_YN: "N", flag: "ACTIVE", sfc, mappedSFC: sfc });
      }
      dlog("initial base cards", base.slice(0, 8));

      setCardData(base);
      originalRef.current = JSON.parse(JSON.stringify(base)) as CardItem[];
      setCurrentPage(1);

      // 2) 저장 이력 머지(실패 무시)
      try {
        const params = { p_plant_cd: plant_cd, p_sfc_cd: sfc, p_work_center: data.WORK_CENTER };
        dlog("sp_escan_detail_q params", params);
        const res = await ax.post("/db/pg/call/mes/sp_escan_detail_q", { params });

        const saved =
          ((res.data?.rows ?? res.data) as
            | { seq: number; pcard_qty: number; input_dt: string | null; prod_dt: string | null }[]
            | undefined) ?? [];

        dlog("sp_escan_detail_q rows (first 8)", Array.isArray(saved) ? saved.slice(0, 8) : saved);

        if (!Array.isArray(saved) || saved.length === 0) return;

        const merged = base.map((row) => {
          const hit = saved.find((s) => Number(s.seq) === Number(row.seq));
          if (!hit) return row;
          const input = hit.input_dt ?? "";
          const prod  = hit.prod_dt  ?? "";
          return {
            ...row,
            input_dt: input,
            prod_dt: prod,
            qty: Number(hit.pcard_qty ?? row.qty),
            confirm_YN: prod ? "P" : input ? "T" : row.confirm_YN,
          };
        });

        dlog("merged cards (first 8)", merged.slice(0, 8));
        setCardData(merged);
        originalRef.current = JSON.parse(JSON.stringify(merged)) as CardItem[];
      } catch (e: any) {
        console.error("❌ load detail (ignored):", e?.response?.data || e);
      }
    })();
  }, [open, plant_cd, work_date, data?.WORK_CENTER, data?.SFC, data?.ORDER_NUMBER]);

  /* ---------------- 12개 단위 배분 ----------------
     서버 플랜 미수신 시 저장 중단(throw) */
  const getAllocationPlan = async (totalQty: number, chunks: { seq: number; qty: number }[]) => {
    const ax = await getMesAxios();

    // (1) 표준/권장 네이밍 (정식 함수) + backlog 포함
    const paramsA = {
      p_plant_cd: plant_cd,
      p_work_center: data.WORK_CENTER,
      p_material_code: data.MATERIAL_CODE,
      p_work_date_txt: work_date,        // 'YYYY-MM-DD'
      p_total_qty: totalQty,
      p_chunk_size: 12,
      p_backlog_mode: "INCLUDE",
    };

    // (2) 레거시 이름을 받는 래퍼가 있을 때만 사용(선택)
    const paramsLegacy = {
      p_plant: plant_cd,
      p_work_center: data.WORK_CENTER,
      p_material_code: data.MATERIAL_CODE,
      p_work_date: work_date,
      p_total_qty: totalQty,
      p_chunk_size: 12,
      p_backlog_mode: "INCLUDE",
    };

    const parseRows = (r: any): Allocation[] => {
      const rows = (r?.data?.rows ?? r?.data ?? []) as any[];
      return Array.isArray(rows)
        ? rows.map((x) => ({
            order_number: String(x.order_number ?? ""),
            zcf_seq: Number(x.zcf_seq ?? x.seq ?? 0),
            qty: Number(x.qty ?? x.pcard_qty ?? 0),
          }))
        : [];
    };

    // A: 정식
    try {
      dlog("assign_pcard_seq(A) params", paramsA);
      const r1 = await ax.post("/db/pg/call/mes/assign_pcard_seq", { params: paramsA });
      const rows1 = parseRows(r1).filter((x) => x.zcf_seq > 0 && x.qty > 0 && x.order_number.length > 0);
      dlog("assign_pcard_seq(A) rows (first 8)", rows1.slice(0, 8));
      if (rows1.length) {
        return [...rows1]
          .sort((a, b) =>
            a.order_number === b.order_number ? a.zcf_seq - b.zcf_seq : a.order_number.localeCompare(b.order_number)
          )
          .slice(0, chunks.length);
      }
    } catch (e: any) {
      console.error("⚠️ assign_pcard_seq(A) failed:", e?.response?.data || e?.message || e);
    }

    // B: 레거시 래퍼(존재할 때만; 없으면 실패할 수 있음)
    try {
      dlog("assign_pcard_seq_legacy(B) params", paramsLegacy);
      const r2 = await ax.post("/db/pg/call/mes/assign_pcard_seq_legacy", { params: paramsLegacy });
      const rows2 = parseRows(r2).filter((x) => x.zcf_seq > 0 && x.qty > 0 && x.order_number.length > 0);
      dlog("assign_pcard_seq_legacy(B) rows (first 8)", rows2.slice(0, 8));
      if (rows2.length) {
        return [...rows2]
          .sort((a, b) =>
            a.order_number === b.order_number ? a.zcf_seq - b.zcf_seq : a.order_number.localeCompare(b.order_number)
          )
          .slice(0, chunks.length);
      }
    } catch (e: any) {
      console.error("⚠️ assign_pcard_seq_legacy(B) failed:", e?.response?.data || e?.message || e);
    }

    console.error("assign_pcard_seq: 서버 플랜을 받지 못했습니다. 저장을 중단합니다.");
    throw new Error("할당 계획 실패(assign_pcard_seq)");
  };

  /* ---------------- 저장 ---------------- */
  const saveBatch = async (list: SavePayload[]) => {
    const ax = await getMesAxios();
    dlog("escan_detail_save payload length", { count: list.length });
    dumpSavePayload("escan_detail_save", list);
    await ax.post("/db/pg/call/mes/escan_detail_save", {
      params: { p_list_json: JSON.stringify(list) },
    });
  };

  const handleSaveDetail = async () => {
    const changed = modified(originalRef.current, cardData)
      .map((it) => (it.confirm_YN === "T" ? { ...it, confirm_YN: "P" as const } : it))
      .filter((it) => it.confirm_YN === "P");

    dlog("handleSaveDetail changed (first 8)", changed.slice(0, 8));
    if (changed.length === 0) return toast(t("toast.noChanges"));

    const targetSeqs = new Set(changed.map((c) => String(c.seq)));
    setCardData((prev) => prev.map((it) => (targetSeqs.has(String(it.seq)) ? { ...it, isSaving: true } : it)));

    try {
      const totalQty = changed.reduce((s, c) => s + Number(c.qty || 0), 0);
      dlog("handleSaveDetail totalQty", totalQty);
      const plan = await getAllocationPlan(totalQty, changed.map((c) => ({ seq: c.seq, qty: c.qty })));
      dlog("handleSaveDetail plan (first 8)", plan.slice(0, 8));

      const rawSfc = safe.sfc10(data?.SFC); // ★ 10자 절단(DB 제약)

      const mk = (p: "P" | "T") =>
        plan.map((al, i): SavePayload => {
          const ch = changed[i] ?? changed[0];

          // ★ 오더 유효성: 10자 절단 + 비정상 값 방지
          const order10 = safe.ord10(al.order_number);
          if (!order10 || order10.includes("-")) throw new Error("할당 계획의 ORDER_NUMBER가 비정상입니다.");

          const seq3 = String(al.zcf_seq).padStart(3, "0");
          const barRaw = `${order10}_${seq3}_${data.MATERIAL_CODE}_${ch.qty}`;
          const bar = safe.bar(barRaw);

          return {
            PLANT_CD: safe.plant(plant_cd),
            BAR_KEY: bar,
            SFC_CD: rawSfc,
            PCARD_SEQ: String(al.zcf_seq),
            PCARD_QTY: ch.qty,
            WORK_CENTER: safe.wc(data.WORK_CENTER),
            ORDER_NUMBER: order10,
            DEVICE_ID: safe.dev("POP_DEVICE_01"),
            USER_IP: safe.ip(localIp),
            SCAN_TYPE: p,
          };
        });

      const payload = [...mk("P"), ...mk("T")];
      dumpSavePayload("handleSaveDetail payload", payload);
      await saveBatch(payload);

      setCardData((prev) =>
        prev.map((it) => (targetSeqs.has(String(it.seq)) ? { ...it, confirm_YN: "Y" as const, isSaving: false } : it))
      );
      dlog("handleSaveDetail success", { affected: changed.length });
      onConfirm?.();
      onClose();
    } catch (e: any) {
      console.error("❌ SaveDetail:", e?.response?.data || e);
      toast(t("toast.saveFailed"));
      setCardData((prev) => prev.map((it) => (targetSeqs.has(String(it.seq)) ? { ...it, isSaving: false } : it)));
    }
  };

  const handleSaveAll = async () => {
    const updated = cardData.map((it) => (it.confirm_YN === "N" ? { ...it, confirm_YN: "P" as const } : it));
    setCardData(updated);

    const targets = updated.filter((x) => !x.prod_dt && x.confirm_YN === "P" && x.flag !== "FINISH");
    dlog("handleSaveAll targets (first 8)", targets.slice(0, 8));
    if (!targets.length) return toast(t("toast.nothingToConfirm"));

    const seqs = new Set(targets.map((t) => t.seq));
    setCardData((prev) => prev.map((it) => (seqs.has(it.seq) ? { ...it, isSaving: true } : it)));

    try {
      const totalQty = targets.reduce((s, c) => s + Number(c.qty || 0), 0);
      dlog("handleSaveAll totalQty", totalQty);
      const plan = await getAllocationPlan(totalQty, targets.map((c) => ({ seq: c.seq, qty: c.qty })));
      dlog("handleSaveAll plan (first 8)", plan.slice(0, 8));

      const rawSfc = safe.sfc10(data?.SFC); // ★ 10자 절단(DB 제약)

      const mk = (p: "P" | "T") =>
        plan.map((al, i): SavePayload => {
          const it = targets[i] ?? targets[0];

          const order10 = safe.ord10(al.order_number);
          if (!order10 || order10.includes("-")) throw new Error("할당 계획의 ORDER_NUMBER가 비정상입니다.");

          const seq3 = String(al.zcf_seq).padStart(3, "0");
          const barRaw = `${order10}_${seq3}_${data.MATERIAL_CODE}_${it.qty}`;
          const bar = safe.bar(barRaw);

          return {
            PLANT_CD: safe.plant(plant_cd),
            BAR_KEY: bar,
            SFC_CD: rawSfc,
            PCARD_SEQ: String(al.zcf_seq),
            PCARD_QTY: it.qty,
            WORK_CENTER: safe.wc(data.WORK_CENTER),
            ORDER_NUMBER: order10,
            DEVICE_ID: safe.dev("POP_DEVICE_01"),
            USER_IP: safe.ip(localIp),
            SCAN_TYPE: p,
          };
        });

      const payload = [...mk("P"), ...mk("T")];
      dumpSavePayload("handleSaveAll payload", payload);
      await saveBatch(payload);

      setCardData((prev) => prev.map((it) => (seqs.has(it.seq) ? { ...it, confirm_YN: "Y" as const, isSaving: false } : it)));
      dlog("handleSaveAll success", { affected: targets.length });
      onConfirm?.();
      onClose();
      toast(t("toast.saveAllDone"));
    } catch (e: any) {
      console.error("❌ SaveAll:", e?.response?.data || e);
      toast(t("toast.saveAllError"));
      setCardData((prev) => prev.map((it) => (seqs.has(it.seq) ? { ...it, isSaving: false } : it)));
    }
  };

  /* ---------------- 필터/페이지 ---------------- */
  const filtered = useMemo(() => {
    const { notStarted, inProgress, completed } = checked;
    if (!notStarted && !inProgress && !completed) return cardData;
    return cardData.filter((c) => {
      if (notStarted && c.confirm_YN === "N") return true;
      if (inProgress && c.confirm_YN === "T") return true;
      if (completed && c.confirm_YN === "P") return true;
      return false;
    });
  }, [cardData, checked]);

  const paged = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  const padded = [...paged, ...Array(Math.max(0, pageSize - paged.length)).fill(null)];
  const rows = Array.from({ length: Math.ceil(padded.length / COLS) }, (_, i) => padded.slice(i * COLS, i * COLS + COLS));
  const totalPages = Math.ceil(filtered.length / pageSize);

  /* ---------------- 카드 렌더링 ---------------- */
  const card = (d: CardItem | null) => {
    if (!d) return <div style={{ height: CARD_HEIGHT }} />;
    const bg = d.isSaving ? "#ffe4e1" : colorOf(d);
    const border = d.isSaving ? "3px solid red" : "none";
    return (
      <div style={{ display: "flex", gap: `${CARD_SIDE_GAP}px`, alignItems: "center", width: "100%", height: CARD_HEIGHT }}>
        <div
          style={{
            flex: 1,
            borderRadius: 10,
            border,
            backgroundColor: bg,
            color: "#000",
            fontWeight: "bold",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            padding: 6,
            boxShadow: "inset 0 0 4px rgba(0,0,0,0.2)",
            fontSize: CARD_FONT_SIZE,
            lineHeight: 1.1,
            gap: `${CARD_ROW_GAP}px`,
            minWidth: 0,
          }}
        >
          {d.isSaving ? (
            <div
              style={{
                fontSize: "2rem",
                fontWeight: "bold",
                color: "#d9534f",
                lineHeight: "2rem",
                minHeight: CARD_HEIGHT,
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
              }}
            >
              {t("ui.inProgress")}
              <br />
            </div>
          ) : (
            <>
              <div>
                {t("detail.pcSeq")} : {d.seq} <br />
                {t("detail.qty")} : {isNaN(d.qty) ? "-" : d.qty}
              </div>
              <div>
                {t("detail.input")} : {d.input_dt || "-"} <br />
                {t("detail.prod")} : {d.prod_dt || "-"}
              </div>
            </>
          )}
        </div>

        {d.isSaving ? (
          <div
            style={{
              width: CARD_BADGE_WH,
              height: CARD_BADGE_WH,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "0.9rem",
              fontWeight: "bold",
              color: "#d9534f",
              border: "2px dashed red",
              borderRadius: 10,
              flexShrink: 0,
            }}
          >
            {t("ui.inProgressShort")}
          </div>
        ) : (
          <img
            src={imgOf(d)}
            alt="OK"
            style={{ width: CARD_BADGE_WH, height: CARD_BADGE_WH, borderRadius: 10, cursor: "pointer", objectFit: "contain", flexShrink: 0 }}
            onClick={() => toggle(d)}
          />
        )}
      </div>
    );
  };

  /* ---------------- 필터 토글(크기 고정) ---------------- */
  const FilterToggle = ({ k, label, bg }: { k: FilterKey; label: string; bg: string }) => {
    const active = checked[k];
    return (
      <label
        style={{
          width: FILTER_BTN_W,
          height: FILTER_BTN_H,
          padding: "0 12px",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 8,
          boxSizing: "border-box",
          backgroundColor: active ? bg : "#444",
          borderRadius: 8,
          border: active ? "2px solid cyan" : "2px solid transparent",
          color: "white",
          fontSize: 26,
          lineHeight: 1,
          whiteSpace: "nowrap",
          userSelect: "none",
          cursor: "pointer",
          flexShrink: 0,
        }}
      >
        <input
          type="checkbox"
          checked={active}
          onChange={(e) => setChecked((prev) => ({ ...prev, [k]: e.target.checked }))}
          style={{ transform: "scale(1.4)", accentColor: "cyan", cursor: "pointer", flexShrink: 0 }}
        />
        <span style={{ display: "inline-block", maxWidth: FILTER_BTN_W - 50, overflow: "hidden", textOverflow: "ellipsis" }}>
          {label}
        </span>
      </label>
    );
  };

  /* ===================== JSX ===================== */
  return (
    <>
      <Toast open={toastOpen}>{toastMessage}</Toast>
      <Dialog open={open} onClose={onClose} style={{ width: "860px", height: "85vh", backgroundColor: "black", color: "white", overflowX: "hidden" }}>
        <div style={{ padding: "1rem" }}>
          <div style={{ display: "flex", justifyContent: "flex-start", gap: `${MAIN_GAP_REM}rem`, marginBottom: "1rem" }}>
            {/* ⬅ 왼쪽 정보 패널 — 가로만 고정, 높이는 자동 */}
            <div
              style={{
                backgroundColor: "black",
                color: "white",
                fontSize: "13px",
                minWidth: LEFT_INFO_W,
                width: LEFT_INFO_W,
                flex: `0 0 ${LEFT_INFO_W}px`,
                height: "auto",
                boxSizing: "border-box",
                flexShrink: 0,
              }}
            >
              <table
                style={{
                  width: "100%",
                  height: "100%",
                  borderCollapse: "collapse",
                  tableLayout: "fixed",
                  border: "1px solid white",
                  boxSizing: "border-box",
                }}
              >
                <tbody>
                  {Object.entries({
                    [t("app.detail.date")]: data?.WORK_DATE ?? "-",
                    [t("app.detail.line")]: data?.WORK_CENTER ?? "-",
                    [t("app.table.model")]: data?.MODEL_CD ?? "-",
                    [t("app.table.styleCode")]: data?.STYLE_CD ?? "-",
                    [t("app.table.materialCode")]: data?.MATERIAL_CODE ?? "-",
                    [t("app.table.materialName")]: data?.MATERIAL_DESCRIPTION ?? "-",
                    [t("app.table.quantity")]: data?.QUANTITY ?? "-",
                    [t("app.detail.size")]: data?.SIZE_CD ?? "-",
                    [t("app.detail.orderNo")]: data?.ORDER_NUMBER ?? "-",
                    [t("app.detail.storage")]: data?.STORAGE ?? "-",
                  }).map(([k, v]) => {
                    const shrink = k === t("app.table.material") || k === t("app.table.description");
                    return (
                      <tr key={k}>
                        <td
                          style={{
                            width: INFO_COL1_W,
                            fontWeight: "bold",
                            padding: "6px 8px",
                            border: "1px solid white",
                            background: "black",
                            whiteSpace: "nowrap",
                            boxSizing: "border-box",
                          }}
                        >
                          • {k}
                        </td>
                        <td
                          style={{
                            padding: "6px 8px",
                            border: "1px solid white",
                            background: "black",
                            boxSizing: "border-box",
                          }}
                        >
                          {shrink ? (
                            <FitTextCell max={13} min={10}>: {String(v ?? "-")}</FitTextCell>
                          ) : (
                            <div style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>: {String(v ?? "-")}</div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* ➡ 오른쪽(제목+필터+버튼) */}
            <div ref={rightRef} style={{ textAlign: "center", marginBottom: "1rem", flex: 1, minWidth: 0 }}>
              <Text style={{ fontSize: "2.6rem", color: "white", fontWeight: "bold", marginTop: "-10px", marginBottom: "0.5rem" }}>
                {t("dialog.confirm.title")}
              </Text>

              <div style={{ display: "flex", justifyContent: "center", gap: "0.75rem", marginBottom: "0.9rem", flexWrap: "wrap" }}>
                <FilterToggle k="notStarted" label={t("filter.notStarted")} bg="#6b6b6b" />
                <FilterToggle k="inProgress" label={t("filter.inProgress")} bg="#b8860b" />
                <FilterToggle k="completed" label={t("filter.completed")} bg="#2e8b57" />
              </div>

              <div style={{ display: "flex", justifyContent: "center", gap: "1.2rem", flexWrap: "wrap" }}>
                <Button icon={saveIcon} className="detail-button" onClick={handleSaveDetail}>
                  {t("button.saveDetail")}
                </Button>
                <Button icon={saveIcon} className="detail-button" onClick={handleSaveAll}>
                  {t("button.saveAll")}
                </Button>
                <Button icon="decline" className="detail-button detail-button-danger" onClick={onClose}>
                  {t("button.close")}
                </Button>
              </div>
            </div>
          </div>

          {/* 카드 영역 */}
          <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
            {rows.map((r, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", gap: "1rem" }}>
                {r.map((d, j) => (
                  <div key={j} style={{ flex: 1, minWidth: 0, overflow: "hidden" }}>
                    {d ? card(d as CardItem) : <div style={{ height: CARD_HEIGHT }} />}
                  </div>
                ))}
              </div>
            ))}
          </div>

          {/* 페이지네이션 */}
          {cardData.length > pageSize && (
            <div style={{ marginTop: "1rem", textAlign: "center" }}>
              {Array.from({ length: totalPages }).map((_, i) => (
                <Button
                  key={i}
                  onClick={() => setCurrentPage(i + 1)}
                  style={{
                    margin: "0 8px",
                    backgroundColor: currentPage === i + 1 ? "cyan" : "#222",
                    color: "white",
                    borderRadius: 8,
                    fontWeight: "bold",
                  }}
                >
                  {i + 1}
                </Button>
              ))}
            </div>
          )}
        </div>
      </Dialog>
    </>
  );
}
