export const PLANT        = "C200";
export const OPERATION    = "";
export const WORKCENTER   = "";
export const RESOURCE     = "";
export const OUT_OR_IN    = "OUT";
export const ACTIVE_TIME  = "10";
export const SAP_ID       = "cheolsoon.hwang@changshininc.com";
